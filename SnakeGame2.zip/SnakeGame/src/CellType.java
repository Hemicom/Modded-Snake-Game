public enum CellType {

    EMPTY,
    FOOD,
    SNAKE_NODE;
}